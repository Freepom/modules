#ifndef _MAIN_H
#define _MAIN_H

#include "stc15w.h"

#define u8 unsigned char
#define u16 unsigned int

#define FOSC    11092500L
#define BAUD    9600
#define T1Timer (65536-FOSC/8000)
#define PinPP(Pn,n) {switch(Pn){\							
			case 0:P0M1 &= ~(1 << n);P0M0 |=  (1 << n);break;\
			case 1:P1M1 &= ~(1 << n);P1M0 |=  (1 << n);break;\
			case 2:P2M1 &= ~(1 << n);P2M0 |=  (1 << n);break;\
			case 3:P3M1 &= ~(1 << n);P3M0 |=  (1 << n);break;\
			case 4:P4M1 &= ~(1 << n);P4M0 |=  (1 << n);break;\
			case 5:P5M1 &= ~(1 << n);P5M0 |=  (1 << n);break;\										
    			default:break;\    									     										
			}\
		    }
		    
#define ClrWDT	{WDT_CONTR |= 0x10;}//�忴�Ź���ι������			

//---------------------------------------------


//-----------------��ѭ���ܹ��Ķ���-----------------------------------

u16 R_MainTemper;
//u8 	R_TimerMSCnt;
u8	R_2ms=0;//2ms��ʱ
bit	Flg_2ms=0;
bit 	Flg_500MsFlash;
char	R_JmpmsCnt=0;

//char	R_MMode=0;
//#define	D_Mode1	0
//#define	D_Mode2	1
//#define	D_Mode3	2
//#define	D_Mode4	3
//#define	D_Mode5	4
//#define	D_Mode6	5

//----------------------------------------------------------
/**********************************************************************************/
//----����ɨ�衢������⡢���������Ķ���-----------------------------------

sbit Pin_TimerSet	= P3^2;
sbit Pin_Key1	 	= P1^5;
sbit Pin_Key2	 	= P1^6;
sbit Pin_Key3	 	= P1^7;
sbit Pin_Key4	 	= P5^4;

#define	nokey		0
#define	D_key1		1
#define	D_key2		2
#define	D_key3		3
#define	D_key4		4
#define	D_keyTimerSet	5
#define	D_keyRelease	6


//----------------------------------------------------------

//----------------------------------------------------------
u8 R_Second,R_Minute,R_Hour;

//----------------------------------------------------------
#endif
