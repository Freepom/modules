
	switch(R_SetMode)
	{
		case 0:
		
			break;	    
		case D_SetMode_Mode:
		
			break;
		case D_SetMode_Day:
		
			break;			
	
		case D_SetMode_Min:
		
			break;
		case D_SetMode_V1:
		
			break;			
		case D_SetMode_V2:
		
			break;
		case D_SetMode_K:
		
			break;	
		case D_SetMode_Frc:
		
			break;
		case D_SetMode_TV:
		
			break;	
		default:
			break;										
	}