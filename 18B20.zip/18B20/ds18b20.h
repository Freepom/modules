#define uchar unsigned char
#define uint unsigned int
void delay5(uchar n);
void init_ds18b20(void);
uchar readbyte(void);
void writebyte(uchar dat);
readtemp(void);