#ifndef HX711_h
#define HX711_h
//#include"HX711.h"
unsigned long ReadCount(void);

#endif